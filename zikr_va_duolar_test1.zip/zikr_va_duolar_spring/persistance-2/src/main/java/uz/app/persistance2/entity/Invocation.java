package uz.app.persistance2.entity;

public interface Invocation {
    Long getId();
    String getName();
    String getArabic();
    String getTransliteration();
    String getTranslation();
}