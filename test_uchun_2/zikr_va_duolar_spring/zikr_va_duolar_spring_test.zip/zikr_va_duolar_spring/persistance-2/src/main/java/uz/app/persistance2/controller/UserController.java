package uz.app.persistance2.controller;

import uz.app.persistance2.datasource.EmailService;
import uz.app.persistance2.datasource.UserRepository;
import uz.app.persistance2.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

@WebServlet("/signup")
public class UserController extends HttpServlet {
    private final UserRepository userRepository = new UserRepository();
    private final EmailService emailService = new EmailService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String gmail = req.getParameter("gmail");

        Optional<User> existingUser = userRepository.findByGmail(gmail);
        if (existingUser.isPresent()) {
            resp.sendRedirect("signup.html?error=exists");
        } else {
            String code = emailService.generateVerificationCode();
            emailService.sendVerificationCode(gmail, code);
            req.getSession().setAttribute("verificationCode", code);
            req.getSession().setAttribute("gmail", gmail);
            req.getSession().setAttribute("name", name);
            resp.sendRedirect("/views/verify.html");
        }
    }
}